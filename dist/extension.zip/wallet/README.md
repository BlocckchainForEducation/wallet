# Wallet for Sawtooth Network

# Usage:

1. Open GG Chrome or MS Edge
2. Open extensions
3. Enable Devmode
4. Drag & Drop build.crx file
