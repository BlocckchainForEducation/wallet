[x] 1. Allow delete account?? Or Hide it.
[x] 2. Allow arrange up/down account in list
[x] 3. Mark if account is imported
[x] 4. Add Tool-tip
[] 5. Prepare devmod
